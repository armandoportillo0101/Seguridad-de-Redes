### Seguridad en Redes y Sistemas de Software

[](https://github.com/armandoportillo0101/Seguridad-de-Redes/blob/main/README.md#seguridad-en-redes-y-sistemas-de-software)

#### Notas de hacking de los retos resueltos durante el semestre

[](https://github.com/armandoportillo0101/Seguridad-de-Redes/blob/main/README.md#notas-de-hacking-de-los-retos-resueltos-durante-el-semestre)

Jose Armando Portillo Reyes [armandoprtillo14@gmail.com](mailto:armandoprtillo14@gmail.com)

##Retos Bandit